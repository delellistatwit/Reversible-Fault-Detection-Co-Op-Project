vlib work
vmap work work
vcom -2008 ../toffoli_gate.vhd
vcom -2008 ../fredkin_gate.vhd
vcom -2008 ../reversible_gates_tb.vhd
vsim work.reversible_gates_tb
add wave sim:/reversible_gates_tb/A
add wave sim:/reversible_gates_tb/B
add wave sim:/reversible_gates_tb/C
add wave sim:/reversible_gates_tb/TP
add wave sim:/reversible_gates_tb/TQ
add wave sim:/reversible_gates_tb/TR
add wave sim:/reversible_gates_tb/FP
add wave sim:/reversible_gates_tb/FQ
add wave sim:/reversible_gates_tb/FR
run 80 ns
wave zoom full
