library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Toffoli (CCNOT) gate:
-- P = A, Q = B, R = C XOR (A AND B)
entity toffoli_gate is
    port (
        A : in  std_logic;
        B : in  std_logic;
        C : in  std_logic;
        P : out std_logic;
        Q : out std_logic;
        R : out std_logic
    );
end entity toffoli_gate;

architecture Behavioral of toffoli_gate is
begin
    P <= A;
    Q <= B;
    R <= C xor (A and B);
end architecture Behavioral;
