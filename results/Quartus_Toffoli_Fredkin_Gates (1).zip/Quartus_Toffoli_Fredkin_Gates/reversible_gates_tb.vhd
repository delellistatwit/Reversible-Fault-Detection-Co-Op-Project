library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity reversible_gates_tb is
end entity reversible_gates_tb;

architecture test of reversible_gates_tb is
    signal A, B, C : std_logic := '0';
    signal TP, TQ, TR : std_logic;
    signal FP, FQ, FR : std_logic;
begin
    TOFFOLI_DUT: entity work.toffoli_gate
        port map (A => A, B => B, C => C, P => TP, Q => TQ, R => TR);

    FREDKIN_DUT: entity work.fredkin_gate
        port map (A => A, B => B, C => C, P => FP, Q => FQ, R => FR);

    stimulus: process
    begin
        for i in 0 to 7 loop
            case i is
                when 0 => A <= '0'; B <= '0'; C <= '0';
                when 1 => A <= '0'; B <= '0'; C <= '1';
                when 2 => A <= '0'; B <= '1'; C <= '0';
                when 3 => A <= '0'; B <= '1'; C <= '1';
                when 4 => A <= '1'; B <= '0'; C <= '0';
                when 5 => A <= '1'; B <= '0'; C <= '1';
                when 6 => A <= '1'; B <= '1'; C <= '0';
                when others => A <= '1'; B <= '1'; C <= '1';
            end case;
            wait for 10 ns;
            assert TP = A and TQ = B and TR = (C xor (A and B))
                report "Toffoli gate output mismatch" severity error;
            assert FP = A and
                   FQ = (((not A) and B) or (A and C)) and
                   FR = (((not A) and C) or (A and B))
                report "Fredkin gate output mismatch" severity error;
        end loop;
        report "Toffoli and Fredkin tests completed for all 8 input combinations."
            severity note;
        wait;
    end process;
end architecture test;
