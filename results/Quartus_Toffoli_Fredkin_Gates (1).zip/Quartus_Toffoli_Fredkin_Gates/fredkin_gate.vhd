library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Fredkin (controlled-swap) gate:
-- P = A
-- Q = (not A AND B) OR (A AND C)
-- R = (not A AND C) OR (A AND B)
-- When A=0, B and C pass through; when A=1, B and C swap.
entity fredkin_gate is
    port (
        A : in  std_logic;
        B : in  std_logic;
        C : in  std_logic;
        P : out std_logic;
        Q : out std_logic;
        R : out std_logic
    );
end entity fredkin_gate;

architecture Behavioral of fredkin_gate is
begin
    P <= A;
    Q <= ((not A) and B) or (A and C);
    R <= ((not A) and C) or (A and B);
end architecture Behavioral;
