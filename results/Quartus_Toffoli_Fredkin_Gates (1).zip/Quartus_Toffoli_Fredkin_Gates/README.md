# Quartus Toffoli and Fredkin Gates — DE10-Lite

This project contains two reversible 3-input/3-output gates and a testbench that exercises all eight input combinations.

## Included files
- `reversible_gates.qpf` — Quartus project
- `reversible_gates.qsf` — MAX 10 device and project settings
- `toffoli_gate.vhd` — Toffoli / CCNOT gate
- `fredkin_gate.vhd` — Fredkin / controlled-swap gate
- `reversible_gates_tb.vhd` — exhaustive 8-case testbench
- `simulation/run_sim.do` — ModelSim/Questa script

## Gate equations

### Toffoli (CCNOT)
- `P = A`
- `Q = B`
- `R = C XOR (A AND B)`

The target bit C flips only when both control bits A and B are 1.

### Fredkin (controlled swap)
- `P = A`
- `Q = (NOT A AND B) OR (A AND C)`
- `R = (NOT A AND C) OR (A AND B)`

When A=0, Q=B and R=C. When A=1, Q=C and R=B.

## Open in Quartus
1. Extract the ZIP.
2. Open `reversible_gates.qpf`.
3. The device is MAX 10 `10M50DAF484C7G` (DE10-Lite).
4. Run **Processing → Start Compilation**.
5. The synthesis top-level defaults to `toffoli_gate`. To compile Fredkin as top-level, open **Assignments → Settings → General** and change the top-level entity to `fredkin_gate`, or edit the QSF as noted there.

The testbench is for simulation only; it is intentionally not included in the Quartus synthesis assignments.

## Run ModelSim simulation
1. Open ModelSim Intel FPGA Edition / Questa.
2. Change directory to the extracted project's `simulation` folder, for example:
   `cd "C:/Users/YOUR_NAME/Downloads/Quartus_Toffoli_Fredkin_Gates/simulation"`
3. Run:
   `do run_sim.do`
4. The testbench checks all 8 combinations and reports completion in the Transcript.

## Truth-table validation
For each of the 8 input combinations, verify the equations above. Save a waveform screenshot and the Transcript result for the assignment evidence.

## Board pin assignments
No pins are assigned in this starter project because both gates expose three inputs and three outputs. Choose and verify six appropriate DE10-Lite switch/LED pins against the official board pinout before programming hardware.
