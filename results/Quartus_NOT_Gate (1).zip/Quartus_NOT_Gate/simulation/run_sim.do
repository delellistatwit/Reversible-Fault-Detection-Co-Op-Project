vlib work
vmap work work
vcom -2008 ../not_gate.vhd
vcom -2008 ../not_gate_tb.vhd
vsim work.not_gate_tb
add wave sim:/not_gate_tb/A
add wave sim:/not_gate_tb/Y
run 20 ns
wave zoom full
