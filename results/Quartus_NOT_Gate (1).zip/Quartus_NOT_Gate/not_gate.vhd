library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- NOT gate: output Y is the complement of input A.
entity not_gate is
    port (
        A : in  std_logic;
        Y : out std_logic
    );
end entity not_gate;

architecture Behavioral of not_gate is
begin
    Y <= not A;
end architecture Behavioral;
