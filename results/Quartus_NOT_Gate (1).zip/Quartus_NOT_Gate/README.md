# Quartus NOT Gate Project — DE10-Lite

## Files
- `not_gate.qpf` — Quartus project
- `not_gate.qsf` — MAX 10 device and example pin assignments
- `not_gate.vhd` — synthesizable NOT gate
- `not_gate_tb.vhd` — testbench for both input values
- `simulation/run_sim.do` — ModelSim/Questa simulation script

## Open in Quartus
1. Extract the ZIP.
2. Open `not_gate.qpf` in Quartus Prime.
3. The target device is MAX 10 `10M50DAF484C7G` (DE10-Lite).
4. Select **Processing → Start Compilation**.

## Run the simulation
1. Open ModelSim Intel FPGA Edition or Questa.
2. In the Transcript, change to the extracted project's `simulation` folder, e.g.:
   `cd "C:/Users/YOUR_NAME/Downloads/Quartus_NOT_Gate/simulation"`
3. Run: `do run_sim.do`
4. The Transcript should report that both input combinations passed.

## Truth table
| A | Y = NOT A |
|---|---|
| 0 | 1 |
| 1 | 0 |

## Example DE10-Lite I/O
- SW0 (`PIN_C10`) -> input A
- LEDR0 (`PIN_A8`) -> output Y

Confirm the pin assignments against the official pinout for your exact board revision before programming the FPGA. The testbench is for simulation only and is not a synthesis source.
