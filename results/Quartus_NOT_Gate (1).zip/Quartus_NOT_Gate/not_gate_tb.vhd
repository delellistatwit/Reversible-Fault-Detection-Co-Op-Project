library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity not_gate_tb is
end entity not_gate_tb;

architecture test of not_gate_tb is
    signal A : std_logic := '0';
    signal Y : std_logic;
begin
    DUT: entity work.not_gate
        port map (A => A, Y => Y);

    stimulus: process
    begin
        A <= '0';
        wait for 10 ns;
        assert Y = '1' report "NOT gate failed for A=0; expected Y=1" severity error;

        A <= '1';
        wait for 10 ns;
        assert Y = '0' report "NOT gate failed for A=1; expected Y=0" severity error;

        report "NOT gate test passed for both input combinations." severity note;
        wait;
    end process;
end architecture test;
