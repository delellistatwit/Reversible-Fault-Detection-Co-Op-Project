library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity reversible_logic is
    port(
        A : in  std_logic;
        B : in  std_logic;
        P : out std_logic;
        Q : out std_logic
    );
end reversible_logic;

architecture Behavioral of reversible_logic is
begin

    -- Feynman/CNOT gate
    P <= A;
    Q <= A xor B;

end Behavioral;