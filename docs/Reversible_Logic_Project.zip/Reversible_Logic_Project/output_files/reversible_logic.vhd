library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity reversible_logic_tb is
end reversible_logic_tb;

architecture Behavioral of reversible_logic_tb is

    component reversible_logic
        port(
            A : in std_logic;
            B : in std_logic;
            P : out std_logic;
            Q : out std_logic
        );
    end component;

    signal A : std_logic := '0';
    signal B : std_logic := '0';
    signal P : std_logic;
    signal Q : std_logic;

begin

    DUT: reversible_logic
        port map(
            A => A,
            B => B,
            P => P,
            Q => Q
        );

    process
    begin

        -- 00
        A <= '0';
        B <= '0';
        wait for 10 ns;

        -- 01
        A <= '0';
        B <= '1';
        wait for 10 ns;

        -- 10
        A <= '1';
        B <= '0';
        wait for 10 ns;

        -- 11
        A <= '1';
        B <= '1';
        wait for 10 ns;

        wait;

    end process;

end Behavioral;