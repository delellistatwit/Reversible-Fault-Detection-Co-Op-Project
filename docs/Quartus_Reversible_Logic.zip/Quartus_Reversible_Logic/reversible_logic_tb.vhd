library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity reversible_logic_tb is
end entity reversible_logic_tb;

architecture Behavioral of reversible_logic_tb is

    signal A : std_logic := '0';
    signal B : std_logic := '0';
    signal P : std_logic;
    signal Q : std_logic;

begin

    DUT: entity work.reversible_logic
        port map (
            A => A,
            B => B,
            P => P,
            Q => Q
        );

    stimulus: process
    begin
        -- 00 -> P=0, Q=0
        A <= '0'; B <= '0';
        wait for 10 ns;

        -- 01 -> P=0, Q=1
        A <= '0'; B <= '1';
        wait for 10 ns;

        -- 10 -> P=1, Q=1
        A <= '1'; B <= '0';
        wait for 10 ns;

        -- 11 -> P=1, Q=0
        A <= '1'; B <= '1';
        wait for 10 ns;

        wait;
    end process;

end architecture Behavioral;
