library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity reversible_logic is
    port (
        A : in  std_logic;
        B : in  std_logic;
        P : out std_logic;
        Q : out std_logic
    );
end entity reversible_logic;

architecture Behavioral of reversible_logic is
begin
    -- Feynman / CNOT gate
    -- Control/pass-through output: P = A
    -- Target output: Q = A XOR B
    P <= A;
    Q <= A xor B;
end architecture Behavioral;
